Readme for the assessment exercise



Contents of this zip file:

	•	sort-employees.jar: contains the program’s executable files
	•	sort-employees-sources.jar: contains the program’s  source code
	•	employee.properties: configuration file that the program reads in order to know where is the input file, where is the output file, and the employees’ data sorting criteria.
	•	log4j2.xml: the program’s logging configuration file (this file can be ignored)
	•	start.bat: Windows script that executes the program
	•	start.sh: Linux script that executes the program
	•	input: folder that contains test input files

How to run the program in a Java 14 enabled computer:

Before running the program, please check that the computer where the program will be run has a Java 14 JRE installed or it will not run properly.


1.	Edit the employee.properties file: 
	a.	Write the input’s file name and path that contains the employees’ data in the employee.inputfile property. Example: employee.inputfile= input/type1.txt
	b.	Write the output’s file name and path that will save the employees’ sorted data in the employee.outputfile property. Example: employee.outputfile= output/sorted.txt
	c.	Write the sorting criteria that the program will use to order the employees. Number 1 is for order by first name, 2 for order by last name, and 3 for order by start date. Example: employee.sort= 1
	d.	Save the employee.properties file.

2.	Run the program. There are 3 options for running the program depending on the running environment. For Windows operating systems options a) and c) are available, for Linux environments options b) and c) can be used.
	a.	Open a windows command terminal in the same location as the start.bat file and type (hit the enter key after the command): .\start.bat
	b.	Open a Linux command terminal  in the same location as the start.sh file and type (hit the enter key after the command): ./start.sh
	c.	Open a command terminal (Windows or Linux) in the same location as the sort-employees.jar file and type (hit the enter key after the command): java -jar sort-employees.jar

3.	The program should have read the input file, sorted the employees’ data, and written the results in the output file. You can look at the contents of the output file to verify if the program ran correctly.
